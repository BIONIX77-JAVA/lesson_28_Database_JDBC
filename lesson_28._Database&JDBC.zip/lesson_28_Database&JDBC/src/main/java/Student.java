public class Student {
    public int id;
    public String name;
    public String secondName;
    public int squad;
    public int age;
    public double averageMark;
}